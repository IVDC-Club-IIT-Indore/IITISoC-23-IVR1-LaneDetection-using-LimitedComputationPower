#!/usr/bin/env python3

# Here we import rospy that enables us to use ROS with Python
import rospy

# we will publish image so we need to import Image
from sensor_msgs.msg import Image

subscriberNodeName = 'angle_subscriber'

# creating topic name over which we will recieve angle messages
angleTopicName = 'angle_topic'

def callbackFunction(message):
	
	#printing message for for confirmation
	rospy.loginfo(" angle recieved ")
	
# initialising subscriber node

rospy.init_node(subscriberNodeName, anonymous = True)

# subsrcribing to the toic
rospy.Subscriber(angleTopicName, uint16_t, callbackFunction)

rospy.spin()

