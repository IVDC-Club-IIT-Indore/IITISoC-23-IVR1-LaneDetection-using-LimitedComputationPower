#!/usr/bin/env python3

# Here we import rospy that enables us to use ROS with Python
import rospy

# we will publish image so we need to import Image
from sensor_msgs.msg import Image

# cv_bridge is a package which we are using for converting opencv image to ros messages and vice-versa
from cv_bridge import CvBridge

import cv2


#creating publisher name
publisherNodeName = 'camera_sensor_publisher'

# creating topic name over which we will transmit image messages

topicName = 'video_feed_topic'

# node initialisation

rospy.init_node(publisherNodeName, anonymous = True)

# creating publisher object, queue_size defines the bugffer size
publisher = rospy.Publisher(topicName, Image, queue_size = 60)

# declaring rate for transmitting messages
rate = rospy.Rate(30)

# creating video capture object for opencv

videoCaptureObject = cv2.VideoCapture(0)

# now creating CvBridge object to convert opencv images to ros message
bridgeObject = CvBridge()


# loop for capturing images and publish via topic
while not rospy.is_shutdown():
	
	#returnvalue is just a boolean fro success/failure
	returnValue, capturedFrame = videoCaptureObject.read()
	
	if returnValue == True:
		# print message just for confirmation
		rospy.loginfo('video frame captured and published')
		 # converting cv image to ros image message
		imageToTransmit = bridgeObject.cv2_to_imgmsg(capturedFrame)
		
		#publishing through topic
		publisher.publish(imageToTransmit)
	
	rate.sleep()
