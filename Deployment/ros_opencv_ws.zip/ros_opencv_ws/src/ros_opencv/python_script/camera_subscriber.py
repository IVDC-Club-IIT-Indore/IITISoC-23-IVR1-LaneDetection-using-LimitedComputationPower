#!/usr/bin/env python3

# Here we import rospy that enables us to use ROS with Python
import rospy
import numpy as np
# we will publish image so we need to import Image
from sensor_msgs.msg import Image

# from tensorflow.keras.models import load_model
import tflite_runtime.interpreter as tflite
# cv_bridge is a package which we are using for converting opencv image to ros messages and vice-versa
from cv_bridge import CvBridge
from std_msgs.msg import Int16
import cv2


# creating subscriber name
subscriberNodeName = 'camera_sensor_subscriber'

# creating topic name over which we will transmit image messages

topicName = 'video_feed_topic'

# creating topic name over which we will transmit angle messages
angleTopicName = 'angle_topic'


# creating publisher object, queue_size defines the buffer size, here change message type according to type of angle
publisher = rospy.Publisher(angleTopicName, Int16, queue_size = 60)

# defining paths for model weights
tflite_model_path = r"/home/bhawna/Downloads/Trained_model.tflite"

interpreter = tflite.Interpreter(model_path=tflite_model_path)
interpreter.allocate_tensors()
input_details = interpreter.get_input_details()
output_details = interpreter.get_output_details()
input_shape = input_details[0]['shape']


# class for lanes
class Lanes():
    def __init__(self):
        self.recent_fit = []
        self.avg_fit = []
        
        
        
# defining function to calculate angle from the output of model
def find_avg_angle(far_center_x , near_center_x , near_center_y ,far_center_y ):
 
 
    sum_angles = 0 
 
    #centers = [ i for i in range(-5, 6,1) ]
    #centers = [  i for i in range(-20, 21,1) ]
    centers = [ i for i in range(-10, 11,1) ]
 
    for i in centers:
 
        rad_angle = np.arctan(  ( far_center_x - (near_center_x + i)) / (near_center_y - far_center_y ) )
        angle = rad_angle*(180/np.pi)
        sum_angles += angle
        
 
    return sum_angles/len(centers)

 # defining callback function which will be called everytime message arrives       
def callbackFunction(message):

    # creating a bridge object
    bridgeObject =  CvBridge()

    #printing message for for confirmation
    rospy.loginfo(" video frame recieved")

    # converting ros image message again to opencv format for further use
    convertedFrame_CV = bridgeObject.imgmsg_to_cv2(message)
    image = convertedFrame_CV

    ###    in this part of code image is passed to model
    lanes = Lanes()
    small_img = cv2.resize(image, (160, 80))    
    # Replace with your preprocessing logic
    small_img_preprocessed = small_img  
    small_img_preprocessed = small_img.astype(np.float32)
    small_img_preprocessed = np.expand_dims(small_img_preprocessed, axis=0)

    # Set the input tensor
    input_index = interpreter.get_input_details()[0]['index']
    interpreter.set_tensor(input_index, small_img_preprocessed)
    interpreter.invoke()
    prediction_matrix = interpreter.get_tensor(interpreter.get_output_details()[0]['index'])[0] * 255.0
    lanes.recent_fit.append(prediction_matrix)
    if len(lanes.recent_fit) > 5:
        lanes.recent_fit = lanes.recent_fit[1:]
    
    lanes.avg_fit = np.mean(np.array([i for i in lanes.recent_fit]), axis=0)
    near_center_x = len(prediction_matrix[0]) // 2
    image_height = len(prediction_matrix)
    near_center_y = image_height
    threshold = 0.5  # You can adjust this threshold based on your specific case
    lane_indices = np.where(prediction_matrix > threshold)[0]  #improve to get actual centre
    print('lane indices: ' , len(lane_indices))
    far_center_y = int(np.mean(lane_indices)) if len(lane_indices) > 0 else near_center_x #avg row 
    out =  np.where( prediction_matrix[far_center_y] > threshold)[0]
    far_center_x = int(np.mean( out  ))
    image_width = len(prediction_matrix[0])
    #max_angle = 45.0  # Maximum angle in degrees
    angle = find_avg_angle(far_center_x , near_center_x , near_center_y ,far_center_y )
    #rad_angle = np.arctan(  ( far_center_x - near_center_x) / (near_center_y - far_center_y ) )
    #angle = rad_angle*(180/np.pi)
    #lane_angle = ((far_center - near_center) / image_width ) * max_angle
    # publishing angle to angleTopicName topic

    publisher.publish(angle)


    start_point_1 = (near_center_x, near_center_y)
    end_point_1 = (near_center_x, far_center_y)
    line_color = (0, 0, 255) 
    # Draw the line on the image
    cv2.line(prediction_matrix, start_point_1, end_point_1, line_color, thickness=2)

    start_point = (near_center_x, near_center_y)
    end_point = (far_center_x, far_center_y)
    
    line_color = (0, 0, 255) 
    # Draw the line on the image
    cv2.line(prediction_matrix, start_point, end_point, line_color, thickness=2)

    blanks = np.zeros_like(lanes.avg_fit).astype(np.uint8)
    lane_drawn = np.dstack((blanks, lanes.avg_fit, blanks))

    cv2.line(lane_drawn, start_point_1, end_point_1, line_color, thickness=2)
    cv2.line(lane_drawn, start_point, end_point, line_color, thickness=2)
    lane_image = cv2.resize(lane_drawn, (640, 480))

    lane_image = cv2.resize(lane_drawn, (640, 480))

    image = cv2.resize(image, (640, 480))
    lane_image = lane_image.astype(np.uint8)
        
        
    result = cv2.addWeighted(image, 1, lane_image, 1, 0)
    cv2.imshow('Lane Detection', result)
    # if ret:
    # for now we don't need to send command for velocity
    # final_angle = int(float(angle)) 
    # rospy.loginfo("Angle: ")
    # rospy.loginfo(final_angle)
    # error_I += angle
    # control_motors(error_I=error_I, angle = angle)
    # else:
    #    rospy.loginfo("Error in capturing frame")

    #for now , we are just showing image on screen .you can remove this if you don't want to show image
    cv2.imshow("camera", convertedFrame_CV)

    cv2.waitkey(1)
	
	
# initialising subscriber node

rospy.init_node(subscriberNodeName, anonymous = True)

# subsrcribing to the toic
rospy.Subscriber(topicName, Image, callbackFunction)

rospy.spin()
cv2.destroyAllWindows()
